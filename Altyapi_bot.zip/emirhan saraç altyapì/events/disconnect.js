module.exports = client => {
  console.log(`Bağnaltın koptu! ${new Date()}`);
};
