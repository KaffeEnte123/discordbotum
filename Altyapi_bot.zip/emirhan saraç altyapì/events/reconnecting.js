module.exports = client => {
  console.log(`Yeniden başlatılıyor ${new Date()}`);
};
